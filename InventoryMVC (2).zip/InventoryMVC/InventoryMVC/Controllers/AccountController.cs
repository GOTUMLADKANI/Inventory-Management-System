﻿using InventoryMVC.Data;
using Microsoft.AspNetCore.Mvc;

namespace InventoryMVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly InventoryDBContext _context;
        public AccountController(InventoryDBContext context)
        {
            _context = context;
        }

        public IActionResult Login()
        {
            HttpContext.Session.Clear(); 
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == username && u.Password == password);
            if (user != null)
            {
                HttpContext.Session.SetString("User", username);
                return RedirectToAction("Index", "Products");
            }
            ViewBag.Error = "Invalid Login";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
